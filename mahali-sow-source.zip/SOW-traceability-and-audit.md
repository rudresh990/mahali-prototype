# Mahali Phase 1 — SOW-locked UI prototype: traceability & scope audit
Source: VM-MAHALI-SOW-PH1-V1.1 (09 Sept 2026). File: `mahali-sow-prototype.html`

## 1. Roles (UI views)
| View | Basis |
|---|---|
| Visitor | Logged-out state. Browse vendors + products/services only; vendor contact hidden (Vendor Contact Actions are for customers) |
| Customer | §5, §6 |
| Vendor | §5, §7 (approved vendors only reach the dashboard) |
| Admin | §5, §8 |

## 2. Screens (19) → SOW
| Screen | Route | SOW requirement |
|---|---|---|
| Browse (Vendors / Products & Services tabs, search, categories, A–Z / Highest rating) | `/` | §10 Search & Discovery; "main Browse page" cards with profile images |
| Vendor profile (gallery, about, address, listings, contact actions) | `/vendor/:id` | §7 Vendor Profile Info; §9; §10 Location + Vendor Contact Actions |
| Listing view (modal) | — | §10 "open and view listing information" |
| Log in | `/login` | §6 Registration & Account Access |
| Password recovery | `/forgot` | §6 "Reset their password" |
| Customer registration | `/register` | §6 (first/last name, phone, email, Emirate, password, user ID) |
| Vendor registration | `/vendor-register` | §7 Vendor Registration; restricted-word block |
| My account | `/account` | §6 "view and update basic account info" |
| Customer feedback | `/feedback` | §6 Customer Feedback Form |
| Application status (pending / rejected + reason + resubmit) | `/vendor-application` | §7 Approval Workflow, notification, resubmit |
| Vendor profile management | `/dashboard/profile` | §7 Profile Management; admin approval of profile changes (§9) |
| Vendor listings (add / edit / remove) | `/dashboard/listings` | §7, §9 Listing Management |
| Subscription (status, plans, Stripe hand-off, reinstate) | `/dashboard/subscription` | §8 Subscription status; §11 |
| Vendor feedback | `/dashboard/feedback` | §7 Vendor Feedback Form |
| Admin overview (basic counts only) | `/admin` | §13 Admin Analytics — included counts |
| Admin vendors (approve / reject with reason, profile-update approval, suspend, subscription status) | `/admin/vendors` | §8 Vendor Management; Subscription & Payment Status |
| Admin customers (view, status) | `/admin/customers` | §8 Customer Management |
| Admin listings (view, status, remove) | `/admin/listings` | §8 Listing Management; §5 (remove listings) |
| Admin categories (add / edit / delete) | `/admin/categories` | §8 Category Management |

## 3. Header items (only what the SOW needs)
- Visitor: Log in · Register as vendor · Register
- Customer: Feedback · My account · Log out
- Vendor: Profile · Listings · Subscription · Feedback · Log out
- Admin: Overview · Vendors · Customers · Listings · Categories · Log out
- Logo → Browse (main page). No Home/Search/Help/Settings/Notifications items. Mobile menu = same items.

## 4. Field limits implemented (§7, §9)
Business name 120 · description 3,000 · address 300 · listing title 120 · listing description 2,000 · price ≤ 2 decimals · images JPG/JPEG/PNG/WebP, ≤ 5 MB, ≤ 4,000×4,000 px · profile images ≤ 50 · listing images ≤ 5 · "Other" category with free-text description.

## 5. Removed vs. the earlier (larger) prototype
Communities, events, offers, blog, reviews/written feedback, messaging/enquiry inbox, notifications page, saved items, onboarding, owner analytics, map/location filters, price/advanced filters, admin reports/moderation queues/settings, traffic analytics (GA4/GSC handle those), feedback analytics.

## 6. Assumptions to confirm (SOW is silent or contradictory)
1. SOW lists 3 roles; **Visitor** is modelled as the logged-out state (per your brief).
2. **Ratings:** SOW shows 1–5 stars for display/sorting but never says who submits them → read-only, no rating input.
3. **Listing availability (In Stock/Out of Stock) and per-listing images** are marked "Will be deleted in the final doc" → availability omitted; listing images kept (a catalogue entry needs one).
4. **"Profile Catalogue Images (max 5)"** vs "Profile Images (50)" is ambiguous → only the 50-image gallery is built.
5. **Feedback form fields** ("agreed form fields") are undefined → placeholder Name, Email, Message. Customer form is in the customer view, vendor form in the vendor view.
6. **Plans/prices** are undefined → two placeholder plans, price "AED xxx".
7. **Restricted-word list** is Mahali-supplied → placeholders (scam, fake, counterfeit).
8. **Admin listing status** = Published / Unpublished (SOW says "manage listing status" without values).
9. **Login field** = "Email or user ID" (registration collects both).
10. **Stripe Checkout** is Stripe-hosted; the prototype shows only a hand-off step and a payment-outcome picker.
11. Newly approved vendors start with "Payment incomplete" and are visible; suspension follows non-payment (SOW §8).
12. The floating **Prototype** button is a reviewer tool for switching role/state — not part of the product.

## 7. Verification run
- 72 screen/viewport combinations (375 / 768 / 1280 × every role/screen) in headless Chromium: no horizontal overflow, no clipped text.
- Automated workflow checks: header items per role; visitor never receives phone/WhatsApp/email/website in the DOM; vendor-selected contact methods only; vendor application → reject with reason → resubmit → approve; profile update held for approval while old profile stays live; listing CRUD + field validation; suspension → Stripe outcome → reinstate; admin counts; role guards.
