'use strict';
const ICONS={
search:'<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
user:'<path d="M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>',
users:'<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
store:'<path d="M3 9 4.5 4h15L21 9"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/><path d="M5 12v8h14v-8"/><path d="M10 20v-5h4v5"/>',
pin:'<path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"/><circle cx="12" cy="10" r="3"/>',
star:'<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>',
phone:'<path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72c.13.96.36 1.9.7 2.81a2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45c.91.34 1.85.57 2.81.7A2 2 0 0 1 22 16.92z"/>',
mail:'<rect x="2" y="4" width="20" height="16" rx="2"/><path d="m22 7-10 6L2 7"/>',
globe:'<circle cx="12" cy="12" r="10"/><path d="M2 12h20"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
msg:'<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 9h8M8 13h5"/>',
check:'<path d="M20 6 9 17l-5-5"/>',
checkcircle:'<circle cx="12" cy="12" r="10"/><path d="m9 12 2 2 4-4"/>',
xcircle:'<circle cx="12" cy="12" r="10"/><path d="m15 9-6 6M9 9l6 6"/>',
x:'<path d="M18 6 6 18M6 6l12 12"/>',
plus:'<path d="M12 5v14M5 12h14"/>',
edit:'<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4z"/>',
trash:'<path d="M3 6h18M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M19 6l-1 14a2 2 0 0 1-2 2H8a2 2 0 0 1-2-2L5 6"/>',
upload:'<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4M17 8l-5-5-5 5M12 3v12"/>',
image:'<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
menu:'<path d="M4 6h16M4 12h16M4 18h16"/>',
arrowL:'<path d="M19 12H5M12 19l-7-7 7-7"/>',
lock:'<rect x="3" y="11" width="18" height="11" rx="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
shield:'<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/><path d="m9 12 2 2 4-4"/>',
clock:'<circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/>',
tag:'<path d="M20.59 13.41 13.42 20.58a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"/><circle cx="7" cy="7" r="1.5"/>',
grid:'<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/>',
alert:'<path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3z"/><path d="M12 9v4M12 17h.01"/>',
info:'<circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>',
card:'<rect x="2" y="5" width="20" height="14" rx="2"/><path d="M2 10h20"/>',
ban:'<circle cx="12" cy="12" r="10"/><path d="m4.9 4.9 14.2 14.2"/>',
refresh:'<path d="M21 12a9 9 0 0 0-15-6.7L3 8M3 3v5h5M3 12a9 9 0 0 0 15 6.7L21 16M21 21v-5h-5"/>',
eye:'<path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/><circle cx="12" cy="12" r="3"/>',
sliders:'<path d="M4 21v-7M4 10V3M12 21v-9M12 8V3M20 21v-5M20 12V3M1 14h6M9 8h6M17 16h6"/>',
coffee:'<path d="M17 8h1a4 4 0 0 1 0 8h-1"/><path d="M3 8h14v9a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z"/><path d="M6 2v3M10 2v3M14 2v3"/>'
};
const ic=(n,c='w-5 h-5')=>`<svg class="${c} shrink-0" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${ICONS[n]||''}</svg>`;
const STAR=ICONS.star.match(/points="([^"]+)"/)[1];
const starF=(c='w-4 h-4')=>`<svg class="${c}" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><polygon points="${STAR}"/></svg>`;
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const A={},F={},I={};
const S=Object.assign({user:null},(()=>{try{return JSON.parse(localStorage.getItem('mahali_sow'))||{}}catch(e){return{}}})());
const persist=()=>{try{localStorage.setItem('mahali_sow',JSON.stringify(S))}catch(e){}};
const role=()=>S.user?S.user.role:'visitor';
let CUR={path:'/'};

/* ── helpers ── */
function toast(msg,type='ok'){const el=document.createElement('div');el.className='anim-up pointer-events-auto flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium shadow-lg max-w-sm '+(type==='err'?'bg-brick text-white':'bg-pine text-white');el.setAttribute('role','status');el.innerHTML=ic(type==='err'?'alert':'checkcircle','w-4 h-4')+`<span>${esc(msg)}</span>`;$('#toast-root').appendChild(el);setTimeout(()=>el.remove(),3400)}
function modal(html,o={}){$('#modal-root').innerHTML=`<div class="fixed inset-0 z-[70] flex items-end sm:items-center justify-center" role="dialog" aria-modal="true"><div class="absolute inset-0 bg-bark/50" data-act="close"></div><div class="relative anim-up w-full ${o.w||'sm:max-w-md'} max-h-[92vh] overflow-y-auto bg-cream rounded-t-3xl sm:rounded-3xl p-5 sm:p-6 shadow-2xl" style="padding-bottom:calc(1.25rem + env(safe-area-inset-bottom,0px))">${html}</div></div>`;document.body.style.overflow='hidden'}
function closeModal(){const r=$('#modal-root');if(r&&r.innerHTML){r.innerHTML='';document.body.style.overflow=''}}
const mHead=(t,s)=>`<div class="flex items-start justify-between gap-4 mb-4"><div class="min-w-0"><h2 class="font-head font-semibold text-lg text-pine">${t}</h2>${s?`<p class="text-sm text-bark/60 mt-0.5">${s}</p>`:''}</div><button data-act="close" class="btn btn-ghost !p-2 -mr-2 -mt-1" aria-label="Close">${ic('x')}</button></div>`;
let CONF=null;
function confirmBox(o){CONF=o.ok;modal(`${mHead(o.title,o.text)}<div class="flex gap-2 justify-end mt-2"><button data-act="close" class="btn btn-outline">Cancel</button><button data-act="confirmOk" class="btn ${o.danger?'btn-danger':'btn-primary'}">${o.label||'Confirm'}</button></div>`)}
A.close=()=>closeModal();A.confirmOk=()=>{const f=CONF;CONF=null;closeModal();f&&f()};
const RESTRICTED=['scam','fake','counterfeit'];/* placeholder — Mahali supplies the real restricted-word list */
const restricted=t=>RESTRICTED.find(w=>new RegExp('\\b'+w+'\\b','i').test(t||''));
const rw=v=>restricted(v)?'This contains a restricted word. Please remove it to continue.':'';
function fld(o){const id='f_'+o.n;let attr=o.attr||'',cnt='';if(o.max){attr+=` maxlength="${o.max}" data-input="cnt"`;cnt=`<span class="text-[11px] text-bark/50" data-cnt="${o.n}">${(o.v||'').length} / ${o.max}</span>`}
 let inner;if(o.opts)inner=`<select id="${id}" name="${o.n}" class="input" ${attr}>${o.opts.map(x=>{const [v,l]=Array.isArray(x)?x:[x,x];return `<option value="${esc(v)}" ${v==o.v?'selected':''}>${esc(l)}</option>`}).join('')}</select>`;
 else if(o.rows)inner=`<textarea id="${id}" name="${o.n}" rows="${o.rows}" class="input" placeholder="${esc(o.ph||'')}" ${attr}>${esc(o.v||'')}</textarea>`;
 else inner=`<div class="relative">${o.ic?`<span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-bark/40">${ic(o.ic,'w-4 h-4')}</span>`:''}<input id="${id}" name="${o.n}" type="${o.t||'text'}" placeholder="${esc(o.ph||'')}" value="${esc(o.v||'')}" autocomplete="${o.ac||'off'}" class="input ${o.ic?'!pl-10':''}" ${attr}></div>`;
 return `<div class="${o.cls||''}"><div class="flex items-end justify-between gap-2 mb-1.5"><label class="label !mb-0" for="${id}">${o.l}${o.req?' <span class="text-brick">*</span>':''}</label>${cnt}</div>${inner}${o.hint?`<p class="text-[11px] text-bark/50 mt-1">${o.hint}</p>`:''}<p class="text-xs text-brick mt-1 hidden" data-err="${o.n}" role="alert"></p></div>`}
I.cnt=t=>{const c=$(`[data-cnt="${t.name}"]`);if(c)c.textContent=t.value.length+' / '+t.maxLength};
const pwFld=(n,l,ac)=>`<div><label class="label" for="f_${n}">${l} <span class="text-brick">*</span></label><div class="relative"><span class="absolute left-3.5 top-1/2 -translate-y-1/2 text-bark/40">${ic('lock','w-4 h-4')}</span><input id="f_${n}" name="${n}" type="password" autocomplete="${ac}" class="input !pl-10 !pr-11"><button type="button" data-act="pwtoggle" class="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 text-bark/50 hover:text-forest" aria-label="Show password">${ic('eye','w-4 h-4')}</button></div><p class="text-xs text-brick mt-1 hidden" data-err="${n}" role="alert"></p></div>`;
A.pwtoggle=t=>{const i=t.parentElement.querySelector('input');i.type=i.type==='password'?'text':'password'};
function collect(root){const d={};$$('[name]',root).forEach(el=>{if(el.type==='checkbox')d[el.name]=el.checked;else if(el.type==='radio'){if(el.checked)d[el.name]=el.value}else if(el.type!=='file')d[el.name]=el.value});return d}
function check(root,rules){const d=collect(root);let ok=true;$$('[data-err]',root).forEach(e=>{e.classList.add('hidden');e.textContent=''});$$('.input',root).forEach(e=>e.classList.remove('!border-brick'));
 for(const k in rules){for(const r of rules[k]){const v=String(d[k]==null?'':d[k]).trim();let m='';
  if(typeof r==='function')m=r(v,d);
  else if(r==='req'&&!v)m='This field is required.';
  else if(r==='email'&&v&&!/^\S+@\S+\.\S+$/.test(v))m='Enter a valid email, like name@example.com.';
  else if(r==='phone'&&v&&!/^\+?[0-9 ]{8,15}$/.test(v))m='Enter a valid phone number, like +971 50 123 4567.';
  else if(r==='min8'&&v.length<8)m='Use at least 8 characters.';
  else if(r==='price'&&v&&!/^\d{1,8}(\.\d{1,2})?$/.test(v))m='Enter a price with up to two decimal places, like 25.50.';
  if(m){ok=false;const e=$(`[data-err="${k}"]`,root);if(e){e.textContent=m;e.classList.remove('hidden')}const i=$(`[name="${k}"]`,root);if(i)i.classList.add('!border-brick');break}}}
 if(!ok){const f=$('[data-err]:not(.hidden)',root);if(f)f.scrollIntoView({block:'center',behavior:'smooth'})}
 return ok?d:null}
A.submit=t=>{const c=t.closest('[data-form]');if(c&&F[c.dataset.form])F[c.dataset.form](c,t)};

/* ── ui bits ── */
const stars=(r,c='w-4 h-4')=>{let s='';for(let i=1;i<=5;i++){const f=r>=i?100:r>i-1?Math.round((r-i+1)*100):0;s+=`<span class="relative inline-block ${c}"><span class="text-sand">${starF(c)}</span><span class="absolute inset-0 overflow-hidden text-gold" style="width:${f}%">${starF(c)}</span></span>`}return `<span class="inline-flex gap-0.5" role="img" aria-label="Rated ${r} out of 5">${s}</span>`};
let _g=0;const PAL=[['#dbd670','#41ccb0'],['#e4dfbe','#30cdb0'],['#ebe979','#7d5738'],['#41ccb0','#2f7a63'],['#f1f0dc','#dbd670'],['#7d5738','#dbd670'],['#30cdb0','#dbd670']];
function art(h,icon='store'){const [a,b]=PAL[Math.abs(h)%PAL.length],g='g'+(++_g);return `<div class="w-full h-full"><svg viewBox="0 0 400 260" preserveAspectRatio="xMidYMid slice" class="w-full h-full block" aria-hidden="true"><defs><linearGradient id="${g}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${b}"/></linearGradient></defs><rect width="400" height="260" fill="url(#${g})"/><circle cx="318" cy="66" r="34" fill="#fff" opacity=".35"/><path d="M0 190Q90 140 190 178T400 160V260H0Z" fill="#fff" opacity=".22"/><path d="M0 225Q110 185 220 218T400 205V260H0Z" fill="#3d3b3a" opacity=".1"/><g transform="translate(164 82) scale(3)" fill="none" stroke="#fff" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" opacity=".92">${ICONS[icon]||''}</g></svg></div>`}
const STAT={pending:['Pending approval','bg-sun/40 text-clay'],approved:['Approved','bg-mist text-forest'],rejected:['Rejected','bg-brick/10 text-brick'],suspended:['Suspended','bg-brick/10 text-brick'],active:['Active','bg-mist text-forest'],Active:['Active','bg-mist text-forest'],'Payment failed':['Payment failed','bg-brick/10 text-brick'],Incomplete:['Payment incomplete','bg-sun/40 text-clay'],Canceled:['Canceled','bg-beige text-bark/60'],published:['Published','bg-mist text-forest'],unpublished:['Unpublished','bg-beige text-bark/60']};
const stat=s=>{const [l,c]=STAT[s]||[s,'bg-beige'];return `<span class="chip ${c}">${l}</span>`};
const empty=(i,t,d,cta='')=>`<div class="text-center py-12 px-4"><div class="mx-auto w-14 h-14 rounded-2xl bg-beige text-forest grid place-items-center">${ic(i,'w-7 h-7')}</div><h3 class="font-head font-semibold text-pine mt-4">${t}</h3><p class="text-sm text-bark/60 mt-1 max-w-sm mx-auto">${d}</p>${cta?`<div class="mt-5 flex flex-wrap gap-2 justify-center">${cta}</div>`:''}</div>`;
const notice=(kind,html)=>{const k={ok:['bg-mist border-mint/40 text-pine','checkcircle'],warn:['bg-sun/30 border-sun text-bark','clock'],err:['bg-brick/10 border-brick/30 text-brick','alert'],info:['bg-beige border-sand text-bark','info']}[kind];return `<div class="rounded-2xl border p-4 flex gap-3 text-sm ${k[0]}" role="status"><span class="mt-0.5">${ic(k[1],'w-5 h-5')}</span><div class="min-w-0 flex-1">${html}</div></div>`};
const logo=(c='h-8')=>`<span class="inline-flex items-center gap-2"><svg viewBox="0 0 48 48" class="${c} w-auto" fill="none" aria-hidden="true"><path d="M8 22 24 8l16 14v18a3 3 0 0 1-3 3H11a3 3 0 0 1-3-3z" stroke="#dbd670" stroke-width="3.5" stroke-linejoin="round" fill="#f1f0dc"/><path d="M24 38V27" stroke="#2f7a63" stroke-width="2.5" stroke-linecap="round"/><path d="M24 29c-6 0-8-4-8-7 5 0 8 2 8 7z" fill="#41ccb0"/><path d="M24 27c0-5 3-7 8-7 0 4-2 7-8 7z" fill="#2f7a63"/></svg><span class="font-display font-bold text-2xl text-pine leading-none">Mahali</span></span>`;
const money=n=>'AED '+Number(n).toFixed(2).replace(/\B(?=(\d{3})+(?!\d))/g,',');
const catName=id=>{const c=DB.cats.find(x=>x.id===id);return c?c.name:'—'};
const catOf=x=>x.cat==='c6'&&x.other?'Other: '+x.other:catName(x.cat);
const pageTitle=(t,s,act='')=>`<div class="flex flex-wrap items-end justify-between gap-3 mb-6"><div class="min-w-0"><h1 class="h1d text-2xl sm:text-3xl">${t}</h1>${s?`<p class="text-sm text-bark/65 mt-1 max-w-xl">${s}</p>`:''}</div>${act}</div>`;
const wrap=(h,w='max-w-7xl')=>`<div class="${w} mx-auto px-4 sm:px-6 py-6 sm:py-8">${h}</div>`;
const back=(h,l)=>`<a href="#${h}" class="inline-flex items-center gap-1.5 text-sm text-forest font-medium mb-4 hover:underline">${ic('arrowL','w-4 h-4')}${l}</a>`;

/* ── header (only SOW-required items, per role) ── */
const NAVS={
 visitor:[['/login','Log in','ghost'],['/vendor-register','Register as vendor','outline'],['/register','Register','secondary']],
 customer:[['/feedback','Feedback'],['/account','My account']],
 vendor:[['/dashboard/profile','Profile'],['/dashboard/listings','Listings'],['/dashboard/subscription','Subscription'],['/dashboard/feedback','Feedback']],
 admin:[['/admin','Overview'],['/admin/vendors','Vendors'],['/admin/customers','Customers'],['/admin/listings','Listings'],['/admin/categories','Categories']]};
const homeOf=()=>({visitor:'/',customer:'/',vendor:'/dashboard',admin:'/admin'}[role()]);
function header(){const r=role(),items=NAVS[r],adm=r==='admin',show=adm?'lg:flex':'md:flex',hide=adm?'lg:hidden':'md:hidden';
 const link=([p,l,k])=>k?`<a href="#${p}" class="btn ${k==='secondary'?'btn-secondary':k==='outline'?'btn-outline':'btn-ghost'}">${l}</a>`:`<a href="#${p}" data-nav="${p}" class="navlink px-3 py-2 rounded-lg text-sm font-head font-medium text-bark/70 hover:text-forest hover:bg-mist">${l}</a>`;
 const out=r!=='visitor'?`<button data-act="logout" class="btn btn-ghost">Log out</button>`:'';
 return `<header class="sticky z-40 bg-cream/95 backdrop-blur border-b border-sand/70" style="top:env(safe-area-inset-top,0px)"><div class="max-w-7xl mx-auto px-4 sm:px-6 h-16 flex items-center gap-3"><a href="#${homeOf()}" aria-label="Mahali">${logo()}</a><div class="flex-1"></div>
 <nav class="hidden ${show} items-center gap-1" aria-label="Main">${items.map(link).join('')}${out}</nav>
 <button data-act="mnav" class="${hide} btn btn-ghost !p-2 -mr-2" aria-label="Menu" aria-expanded="false">${ic('menu')}</button></div>
 <nav id="mnav" class="hidden ${hide} border-t border-sand/70 bg-cream px-4 py-3 flex-col gap-1" aria-label="Menu">${items.map(([p,l])=>`<a href="#${p}" data-nav="${p}" class="navlink px-3 py-3 rounded-lg text-sm font-head font-medium text-bark/80">${l}</a>`).join('')}${r!=='visitor'?`<button data-act="logout" class="text-left px-3 py-3 rounded-lg text-sm font-head font-medium text-bark/80 hover:bg-mist">Log out</button>`:''}</nav></header>`}
A.mnav=t=>{const n=$('#mnav');const open=n.classList.contains('hidden');n.classList.toggle('hidden',!open);n.classList.toggle('flex',open);t.setAttribute('aria-expanded',open)};
function markNav(path){$$('[data-nav]').forEach(a=>a.classList.toggle('on',a.dataset.nav===path||(a.dataset.nav!=='/'&&path.startsWith(a.dataset.nav+'/'))))}
A.logout=()=>{S.user=null;persist();toast('You have been logged out.');if((location.hash||'#/')==='#/')nav();else location.hash='#/'};

/* ── router ── */
const R=[];const route=(p,h)=>R.push([new RegExp('^'+p.replace(/:(\w+)/g,'([^/]+)')+'$'),h]);
function nav(){const raw=location.hash.slice(1)||'/',i=raw.indexOf('?'),path=i<0?raw:raw.slice(0,i);
 for(const [re,h] of R){const m=path.match(re);if(m){let r;try{r=h(...m.slice(1).map(decodeURIComponent))}catch(e){console.error(e);r={title:'Error',html:wrap(empty('alert','Something went wrong','Please go back and try again.'))}}
  if(r&&r.redirect){location.hash='#'+r.redirect;return}render(r,path);return}}
 render({title:'Page not found',html:wrap(empty('search','Page not found','This page does not exist.',`<a href="#${homeOf()}" class="btn btn-primary">Go back</a>`),'max-w-lg')},path)}
function render(r,path){closeModal();CUR={path};$('#app').innerHTML=`${header()}<main id="main">${r.html}</main>`;document.title=(r.title?r.title+' · ':'')+'Mahali';markNav(path);window.scrollTo(0,0);if(r.after)r.after()}
const rerender=()=>nav();
function gate(roles,label){if(roles.includes(role()))return null;
 return{title:'Access',html:wrap(role()==='visitor'?empty('lock','Log in to continue','This page is available after you log in.',`<a href="#/login" class="btn btn-primary">Log in</a><a href="#/register" class="btn btn-secondary">Register</a>`):empty('lock','Not available for your role','This page is only available to '+label+'.',`<a href="#${homeOf()}" class="btn btn-primary">Go back</a>`),'max-w-lg')}}

/* ── global events ── */
document.addEventListener('click',e=>{const t=e.target.closest('[data-act]');if(!t)return;const f=A[t.dataset.act];if(f){if(t.tagName!=='A'||t.getAttribute('href')==='#')e.preventDefault();f(t,e)}});
document.addEventListener('input',e=>{const t=e.target;if(t.dataset&&t.dataset.input&&I[t.dataset.input])I[t.dataset.input](t,e)});
document.addEventListener('change',e=>{const t=e.target;if(t.dataset&&t.dataset.change&&I[t.dataset.change])I[t.dataset.change](t,e)});
document.addEventListener('keydown',e=>{const t=e.target;if(e.key==='Escape')closeModal();
 if(e.key==='Enter'&&t.tagName==='INPUT'&&!['file','checkbox','radio'].includes(t.type)){const c=t.closest('[data-form]'),b=c&&c.querySelector('[data-act="submit"]');if(b){e.preventDefault();b.click()}}});
window.addEventListener('hashchange',nav);
