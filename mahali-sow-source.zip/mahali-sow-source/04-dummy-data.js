/* ── Dummy data (only entities the SOW requires) ── */
const EM=['Abu Dhabi','Dubai','Sharjah','Ajman','Umm Al Quwain','Ras Al Khaimah','Fujairah'];
const DB={
 cats:[{id:'c1',name:'Food & Beverage'},{id:'c2',name:'Home Services'},{id:'c3',name:'Health & Wellness'},{id:'c4',name:'Fashion & Accessories'},{id:'c5',name:'Education'},{id:'c6',name:'Other'}],
 plans:[{id:'pm',name:'Monthly plan',dur:'Billed every month'},{id:'py',name:'Annual plan',dur:'Billed every 12 months'}],
 vendors:[
 ['v1','Green Leaf Café','c1','Al Barsha, Dubai',4.8,24,0,'approved','Active','15 Oct 2026',['call','whatsapp','email','website'],'Farm-to-table breakfasts, single-origin coffee and a quiet garden corner. Our kitchen sources ingredients from local growers and everything is prepared fresh each morning.'],
 ['v2','Palm Wellness Studio','c3','Jumeirah, Dubai',4.9,12,3,'approved','Active','02 Nov 2026',['call','whatsapp'],'Massage, physiotherapy and recovery sessions in a calm seaside studio with qualified practitioners.'],
 ['v3','Al Noor Home Care','c2','Deira, Dubai',4.6,9,2,'approved','Active','28 Oct 2026',['call','whatsapp','email'],'Reliable AC servicing, plumbing and deep-cleaning teams available across Dubai.'],
 ['v4','Souk Bazaar Gifts','c4','Al Karama, Dubai',4.4,50,5,'approved','Active','09 Nov 2026',['email','website'],'Handmade gifts, oud and keepsakes from UAE and regional makers.'],
 ['v5','Little Sprouts Nursery','c5','Mirdif, Dubai',4.7,18,1,'approved','Active','20 Oct 2026',['call','email'],'A play-led nursery with bilingual teachers and a shaded outdoor garden.'],
 ['v6','Amal Beauty Lounge','c3','Business Bay, Dubai',4.5,15,6,'suspended','Payment failed','—',['call','whatsapp'],'Hair, nails and skincare in a relaxed lounge setting.'],
 ['v7','QuickFix Auto Garage','c2','Al Quoz, Dubai',4.3,6,2,'approved','Active','12 Oct 2026',['call','whatsapp'],'Honest servicing and repairs with photo updates while you wait.'],
 ['v8','Majaz Bites','c1','Al Majaz, Sharjah',4.7,20,0,'approved','Active','30 Oct 2026',['call','whatsapp','website'],'Shawarma, grills and karak overlooking the Al Majaz waterfront.'],
 ['v9','Desert Rose Bakery','c1','Al Majaz, Sharjah',null,4,4,'pending',null,'—',['call','email'],'Small-batch breads, pastries and cakes baked daily.'],
 ['v10','Sand & Stone Interiors','c2','Khalidiyah, Abu Dhabi',null,7,5,'rejected',null,'—',['email','website'],'Interior fit-out and furniture sourcing for homes and offices.'],
 ['v11','Falcon Movers','c2','Al Nuaimiya, Ajman',4.2,5,6,'suspended','Canceled','—',['call'],'Packing and moving across the northern emirates.']
 ].map(([id,name,cat,address,rating,imgs,hue,status,sub,billEnd,methods,desc],i)=>({id,name,cat,other:'',desc,address,phone:'+971 4 555 0'+(140+i*7),wa:'+971 50 555 0'+(140+i*7),email:'hello@'+name.toLowerCase().replace(/[^a-z]+/g,'')+'.ae',web:name.toLowerCase().replace(/[^a-z]+/g,'')+'.ae',methods,rating,imgs,hue,status,sub,billEnd,reason:id==='v10'?'The business address is incomplete. Please add the full street address and resubmit.':'',upd:null,updReject:'',canReinstate:false,justApproved:false})),
 listings:[
 ['l1','v1','Weekend brunch platter','Seasonal fruit, eggs any style, sourdough toast and a hot drink of your choice.','c1',68],
 ['l2','v1','Single-origin coffee beans (250 g)','Medium roast beans, roasted weekly.','c1',42.5],
 ['l3','v1','Office catering trays','Sandwich and salad trays for small teams. Price on request.','c1',null],
 ['l4','v2','60-minute deep tissue massage','Focused treatment to release tension. Booking by phone.','c3',280],
 ['l5','v2','Recovery session','Guided stretching and foam-rolling session.','c3',150],
 ['l6','v3','AC service','Full clean and gas check for split and window units.','c2',120],
 ['l7','v3','Deep home cleaning','Two-person team, all supplies included.','c2',250],
 ['l8','v4','Hand-poured oud candle','Small-batch candle in a reusable glass jar.','c4',95],
 ['l9','v4','Personalised leather passport holder','Embossed with up to three initials.','c4',110],
 ['l10','v5','Half-day nursery place','Monthly place for ages 2–4.','c5',1450],
 ['l11','v7','Oil and filter change','Includes a basic vehicle check.','c2',160],
 ['l12','v8','Chicken shawarma wrap','Served with pickles and garlic sauce.','c1',18],
 ['l13','v8','Karak tea (large)','Freshly brewed karak.','c1',6],
 ['l14','v3','Custom service request','Other service type — described by vendor.','c6',null]
 ].map(([id,vid,title,desc,cat,price],i)=>({id,vid,title,desc,cat,other:cat==='c6'?'Handyman services':'',price,hue:i%7,status:'published'})),
 customers:[
 ['u1','Sara','Al Mansoori','sara@demo.ae','+971 50 555 0111','Dubai','saraam',3],
 ['u2','James','Parker','james.p@mail.com','+971 55 555 0122','Dubai','jamesp',1],
 ['u3','Fatima','Khalid','fatima.k@mail.ae','+971 52 555 0133','Sharjah','fatimak',5],
 ['u4','Rahul','Menon','rahul.m@mail.com','+971 56 555 0144','Abu Dhabi','rahulm',1],
 ['u5','Noor','Hussain','noor.h@mail.ae','+971 54 555 0155','Ajman','noorh',2],
 ['u6','Lucas','Meyer','lucas.m@mail.com','+971 58 555 0166','Dubai','lucasm',0]
 ].map(([id,first,last,email,phone,emirate,uid,logins],i)=>({id,first,last,email,phone,emirate,uid,logins,status:i===5?'suspended':'active'}))
};
DB.vendors[6].upd={desc:'QuickFix Auto Garage offers honest servicing and repairs, and now also same-day tyre replacement, with photo updates while you wait.',address:'Al Quoz Industrial 3, Dubai',date:'19 Sep 2026'};
const vendor=id=>DB.vendors.find(v=>v.id===id);
const isPublic=v=>v.status==='approved';
const listingsOf=vid=>DB.listings.filter(l=>l.vid===vid);
const pubListings=()=>DB.listings.filter(l=>l.status==='published'&&isPublic(vendor(l.vid)));
/* Prototype reviewer control — NOT part of the product UI. Lets reviewers preview each role/state. */
const DEMO={
 visitor:null,
 customer:{role:'customer',cid:'u1',name:'Sara Al Mansoori'},
 vendor:{role:'vendor',vid:'v1',name:'Green Leaf Café'},
 'vendor-pending':{role:'vendor',vid:'v9',name:'Desert Rose Bakery'},
 'vendor-rejected':{role:'vendor',vid:'v10',name:'Sand & Stone Interiors'},
 'vendor-suspended':{role:'vendor',vid:'v6',name:'Amal Beauty Lounge'},
 admin:{role:'admin',name:'Administrator'}
};
const me=()=>S.user&&S.user.role==='vendor'?vendor(S.user.vid):null;
const meC=()=>S.user&&S.user.role==='customer'?DB.customers.find(c=>c.id===S.user.cid):null;
